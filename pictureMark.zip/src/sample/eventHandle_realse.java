package sample;

import javafx.event.EventHandler;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;


import java.util.List;
//由于需要通过realse关闭事件监听（鼠标拖拽事件），所以不能通过匿名内部类实现接口，需要自己额外实现响应事件
public  class eventHandle_realse implements EventHandler<MouseEvent> {
    Information information;
    List<Information>mark_list;
    TextField markfield;
    EventHandler<MouseEvent>eventHandler;
    EventHandler<MouseEvent>eventHandler_realse;
    Pane image_pane;
    void setself(EventHandler<MouseEvent> eventHandler_realse){
        this.eventHandler_realse=eventHandler_realse;
    }
    eventHandle_realse(Information information, List<Information>mark_list,
                        TextField markfield,
                       Pane image_pane,EventHandler<MouseEvent>eventHandler){
        this.information=information;
        this.mark_list=mark_list;
        this.markfield=markfield;
        this.eventHandler=eventHandler;
        this.image_pane=image_pane;
    }
    public void handle(MouseEvent mouseEvent2){
        System.out.println("realse");
        image_pane.removeEventHandler(MouseEvent.MOUSE_DRAGGED,eventHandler );
        if(information.Paddng){
            information.start_x=information.r.getX();
            information.start_y=information.r.getY();
            information.end_x=information.r.getX()+information.r.getWidth();
            information.end_y=information.r.getY()+information.r.getHeight();
            information.change_to_String();
            information.mark_text = markfield.getText();
            if(information.isBox()){
                mark_list.add(information);
            }else{
                //不是框就清除
               image_pane.getChildren().remove(information.r);
            }
        }else
        //标注框节点信息填充,并加入mark_list
         {
            information.start_x = information.a1.getStartX();
            information.start_y = information.a1.getStartY();
            information.end_x = information.a4.getEndX();
            information.end_y = information.a4.getEndY();
            information.change_to_String();
            information.mark_text = markfield.getText();
            if(information.isBox()){
                mark_list.add(information);
            }else{
                //不是框就清除
                image_pane.getChildren().remove(information.a1);
                image_pane.getChildren().remove(information.a2);
                image_pane.getChildren().remove(information.a3);
                image_pane.getChildren().remove(information.a4);
            }


        }
        image_pane.removeEventHandler(MouseEvent.MOUSE_RELEASED,this);

    }
}