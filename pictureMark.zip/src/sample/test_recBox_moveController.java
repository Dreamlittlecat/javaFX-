package sample;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;

public class test_recBox_moveController extends Application {
   /* Line a1=new Line();
    Line a2=new Line();
    Line a3=new Line();
    Line a4=new Line();*/
    Boolean box_flag=false;
    Boolean read_flag=true;
    double x0t,y0t;
    double delta_x,delta_y;
  //  double x0=417.59999999999997,x1=314.4,y0=450.3999999999999,y1=352.0;
    List<Information>mark_list;
    BigMachine_select_box bigMachine_select_box;
    @FXML
    private Button but;

    @FXML
    private Pane test_pane;

    @FXML
    private Pane test_pane1;
    @FXML
    private Button start;
    @FXML
    private ListView<String> picture_dir;
    @FXML
    void my_start(ActionEvent event) {
        ObservableList<String> data = FXCollections.observableArrayList(
                "chocolate", "salmon", "gold", "coral", "darkorchid",
                "darkgoldenrod", "lightsalmon", "black", "rosybrown", "blue",
                "blueviolet", "brown");
        picture_dir.setItems(data);
        mark_list=new ArrayList<>();
        Mark_xmlDom_read mark_xmlDom_read = new Mark_xmlDom_read(mark_list,"C:\\Users\\xia23\\Pictures\\pexels-cottonbro-6853286.xml");
        mark_xmlDom_read.Read();
        System.out.println(mark_list.size());
        for(int i=0;i<mark_list.size();i++){
            System.out.println(i);
            Information t=mark_list.get(i);
            t.change();
            add2(t.start_x,t.start_y,t.end_x,t.end_y,t.a1,t.a2,t.a3,t.a4);
          //  System.out.println(t);
            //保留原有的画框，需要用read_mark_list初始化mark_list

        }
    }

    @FXML
    void mybut(ActionEvent event) {
        test_pane1.addEventHandler(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                //System.out.println("listen");
                for(int i=0;i<mark_list.size();i++){
                    Information t=mark_list.get(i);
                   // System.out.println(t);
                    if(mouseEvent.getX()>t.start_x&&mouseEvent.getY()>t.start_y&&
                         mouseEvent.getX()<t.end_x&&mouseEvent.getY()<t.end_y){
                        System.out.println("xuanzhong"+i);
                        System.out.println(t.judgeDistract(mouseEvent.getX(), mouseEvent.getY()));
                        bigMachine_select_box=new BigMachine_select_box(t,test_pane1,mouseEvent.getX(), mouseEvent.getY());
                        bigMachine_select_box.select();
                        break;
                    }
                }
            }
        });


    }
Stage stage;
    @Override
    public void start(Stage primaryStage) throws Exception{
        stage=primaryStage;
        Parent root = FXMLLoader.load(getClass().getResource("test_recBox_move.fxml"));
        primaryStage.setTitle("picture marktool" );
        primaryStage.setScene(new Scene(root, 700, 675));
        primaryStage.show();

    }
       // init_k();


    public void add2(double x0,double y0,double x1,double y1,Line a1,Line a2,Line a3,Line a4){
        // test_pane1=new Pane();

        Pane image_pane=new AnchorPane();
        // double x0=417.59999999999997,x1=314.4,y0=450.3999999999999,y1=352.0;
        a1.setStartX(x0);
        a2.setStartX(x0);
        a3.setStartX(x1);
        a4.setStartX(x0);
        a1.setStartY(y0);
        a2.setStartY(y0);
        a3.setStartY(y0);
        a4.setStartY(y1);
        a1.setEndX(x1);
        a2.setEndX(x0);
        a3.setEndX(x1);
        a4.setEndX(x1);
        a1.setEndY(y0);
        a2.setEndY(y1);
        a3.setEndY(y1);
        a4.setEndY(y1);
        image_pane.getChildren().add(a1);
        image_pane.getChildren().add(a2);
        image_pane.getChildren().add(a3);
        image_pane.getChildren().add(a4);
        test_pane1.getChildren().add(image_pane);
        box_flag=true;
    }

    class BigMachine_select_box{
        Information information;
        Pane pane;
        EventHandler<MouseEvent>press;//=new rec_box_move0();
        EventHandler<MouseEvent> drag;//=new rec_box_move1(information);
        EventHandler<MouseEvent> release;//=new rec_box_move2(press,drag);
        double x0t,y0t;
        double delta_x,delta_y;
       // double x,y;
        BigMachine_select_box(Information information,Pane pane,double x,double y){
            press=new rec_box_move0();
            this.pane=pane;
            this.information=information;
            drag=new rec_box_move1(information,information.judgeDistract(x,y));
            release=new rec_box_move2(press,drag,information,information.judgeDistract(x,y));
        }
        void select(){
           // add2();
            System.out.println(information);
            pane.addEventHandler(MouseEvent.MOUSE_PRESSED,press);
            pane.addEventHandler(MouseEvent.MOUSE_DRAGGED,drag);
            pane.addEventHandler(MouseEvent.MOUSE_RELEASED,release);
        }
        void select_giveup(){
            pane.removeEventHandler(MouseEvent.MOUSE_RELEASED,release);
            pane.removeEventHandler(MouseEvent.MOUSE_DRAGGED,drag);
            pane.removeEventHandler(MouseEvent.MOUSE_PRESSED,press);
        }
        class rec_box_move0 implements EventHandler<MouseEvent>{

            @Override
            public void handle(MouseEvent mouseEvent) {
                System.out.println("鼠标点击");
                x0t=mouseEvent.getX();
                y0t= mouseEvent.getY();
                // System.out.println(x0t+" "+x1+" "+y0t+" "+y1);
                //                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            test_pane1.removeEventHandler(MouseEvent.MOUSE_PRESSED,this);
            }
        }
        class rec_box_move1 implements EventHandler<MouseEvent>{
            Information information;
            int distract_flag=0;
            rec_box_move1(Information information,int k){
                this.information=information;
                distract_flag=k;
            }
            @Override
            public void handle(MouseEvent mouseEvent) {
                //   double delta_x,delta_y;

                delta_x=mouseEvent.getX()-x0t;
                delta_y=mouseEvent.getY()-y0t;
                // add(x0,y0,x1,y1);
                // System.out.println("move2:"+delta_x+" "+delta_y);
                switch (distract_flag){
                    case 1://只改左上点坐标
                        add2(information.start_x+delta_x, information.start_y+delta_y,
                                information.end_x, information.end_y,
                                information.a1, information.a2, information.a3, information.a4);
                        break;
                    case 2:
                        //右上点
                        add2(information.start_x, information.start_y+delta_y,
                                information.end_x+delta_x, information.end_y,
                                information.a1, information.a2, information.a3, information.a4);
                        break;
                    case 3:
                        //左下点
                        add2(information.start_x+delta_x, information.start_y,
                                information.end_x, information.end_y+delta_y,
                                information.a1, information.a2, information.a3, information.a4);
                        break;
                    case 4:
                        //只改右下点坐标
                        add2(information.start_x, information.start_y,
                                information.end_x+delta_x, information.end_y+delta_y,
                                information.a1, information.a2, information.a3, information.a4);
                        break;
                    case 5:
                        //上边线
                        add2(information.start_x, information.start_y+delta_y,
                                information.end_x, information.end_y,
                                information.a1, information.a2, information.a3, information.a4);
                        break;
                    case 6:
                        //下边线
                        add2(information.start_x, information.start_y,
                                information.end_x, information.end_y+delta_y,
                                information.a1, information.a2, information.a3, information.a4);
                        break;
                    case 7:
                        //左边线
                        add2(information.start_x+delta_x, information.start_y,
                                information.end_x, information.end_y,
                                information.a1, information.a2, information.a3, information.a4);
                        break;
                    case 8:
                        //右边线
                        add2(information.start_x, information.start_y,
                                information.end_x+delta_x, information.end_y,
                                information.a1, information.a2, information.a3, information.a4);
                        break;
                    case 9:
                        //全局移动
                        add2(information.start_x+delta_x, information.start_y+delta_y,
                                information.end_x+delta_x, information.end_y+delta_y,
                                information.a1, information.a2, information.a3, information.a4);
                        break;
                    default:;

                }
            }
        }
        class rec_box_move2 implements EventHandler<MouseEvent>{
            EventHandler<MouseEvent>move0,move1;
            Information information;
            int distract_flag=0;
            rec_box_move2(EventHandler<MouseEvent>move0,EventHandler<MouseEvent>move1,Information information,int k){
                this.move0=move0;
                this.move1=move1;
                this.information=information;
                this.distract_flag=k;
            }

            @Override
            public void handle(MouseEvent mouseEvent) {
                System.out.println("release:"+delta_x+" "+delta_y);
                switch (distract_flag){
                    case 1://只改左上点坐标
                        information.start_x= information.start_x+delta_x;
                        information.start_y=information.start_y+delta_y;

                        break;
                    case 2:
                        //右上点
                        information.start_y=information.start_y+delta_y;
                        information.end_x=information.end_x+delta_x;

                        break;
                    case 3:
                        //左下点
                        information.start_x= information.start_x+delta_x;
                        information.end_y= information.end_y+delta_y;

                        break;
                    case 4:
                        //只改右下点坐标
                        information.end_x=information.end_x+delta_x;
                        information.end_y= information.end_y+delta_y;

                        break;
                    case 5:
                        //上边线
                        information.start_y=information.start_y+delta_y;

                        break;
                    case 6:
                        //下边线
                        information.end_y= information.end_y+delta_y;

                        break;
                    case 7:
                        //左边线
                        information.start_x= information.start_x+delta_x;

                        break;
                    case 8:
                        //右边线
                        information.end_x=information.end_x+delta_x;

                        break;
                    case 9:
                        //全局移动
                        information.start_x= information.start_x+delta_x;
                        information.start_y=information.start_y+delta_y;
                        information.end_x=information.end_x+delta_x;
                        information.end_y= information.end_y+delta_y;

                        break;
                    default:;

                }
                information.change_to_String();
                System.out.println(information);
                System.out.println("start_x"+information.start_x);
                delta_x=0;
                delta_y=0;
                x0t=mouseEvent.getX();
                y0t= mouseEvent.getY();
                test_pane1.removeEventHandler(MouseEvent.MOUSE_PRESSED,move0);
                test_pane1.removeEventHandler(MouseEvent.MOUSE_DRAGGED,move1);
                test_pane1.removeEventHandler(MouseEvent.MOUSE_RELEASED,this);
            }}
    }
}

