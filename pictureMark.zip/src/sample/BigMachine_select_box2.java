package sample;

import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;
//对既有框编辑的接口
public class BigMachine_select_box2{
    Information information;//传入节点
    Pane pane;//传入pane
    EventHandler<MouseEvent> press;//=new rec_box_move0();
    EventHandler<MouseEvent> drag;//=new rec_box_move1(information);
    EventHandler<MouseEvent> release;//=new rec_box_move2(press,drag);
    double x0t,y0t;//定义锚点，即鼠标开始拖拽的初始位置
    double delta_x,delta_y;//定义x,y坐标的偏移值

    BigMachine_select_box2(Information information,Pane pane,double x,double y){
        //double x,y是为了得到鼠标点击时的位置
        press=new rec_box_move0();
        this.pane=pane;
        this.information=information;
        drag=new rec_box_move1(information,information.judgeDistract(x,y));
        release=new rec_box_move2(press,drag,information,information.judgeDistract(x,y));
    }
    void select(){
        // add2();
        //该框被选中，增加事件监听事件
        System.out.println(information);
        pane.addEventHandler(MouseEvent.MOUSE_PRESSED,press);
        pane.addEventHandler(MouseEvent.MOUSE_DRAGGED,drag);
        pane.addEventHandler(MouseEvent.MOUSE_RELEASED,release);
    }
    void select_giveup(){
        pane.removeEventHandler(MouseEvent.MOUSE_RELEASED,release);
        pane.removeEventHandler(MouseEvent.MOUSE_DRAGGED,drag);
        pane.removeEventHandler(MouseEvent.MOUSE_PRESSED,press);
    }
    //重写画框函数，这次将四条边作为参数传入
    void add2(double x0, double y0, double x1, double y1, Line a1, Line a2, Line a3, Line a4) {
        if(information.Paddng){//填充画矩形
            add3(x0,y0,x1,y1);
        }else{//非填充画矩形
        a1.setStartX(x0);
        a2.setStartX(x0);
        a3.setStartX(x1);
        a4.setStartX(x0);
        a1.setStartY(y0);
        a2.setStartY(y0);
        a3.setStartY(y0);
        a4.setStartY(y1);
        a1.setEndX(x1);
        a2.setEndX(x0);
        a3.setEndX(x1);
        a4.setEndX(x1);
        a1.setEndY(y0);
        a2.setEndY(y1);
        a3.setEndY(y1);
        a4.setEndY(y1);}
    }
    void add3(double x0, double y0, double x1, double y1){
        information.r.setX(x0);
        information.r.setY(y0);
        information.r.setWidth(x1-x0);
        information.r.setHeight(y1-y0);
    }
    class rec_box_move0 implements EventHandler<MouseEvent>{

        @Override
        public void handle(MouseEvent mouseEvent) {
            //设置锚点坐标
            x0t=mouseEvent.getX();
            y0t= mouseEvent.getY();

        }
    }
    class rec_box_move1 implements EventHandler<MouseEvent>{
        Information information;
        int distract_flag=0;
        rec_box_move1(Information information,int k){
            this.information=information;
            distract_flag=k;
        }
        @Override
        public void handle(MouseEvent mouseEvent) {
            //   double delta_x,delta_y;
            //获得偏移坐标
            delta_x=mouseEvent.getX()-x0t;
            delta_y=mouseEvent.getY()-y0t;
           //更改图形参数（对应每个四个点和四条边和中心区域的操作不同）
            switch (distract_flag){
                case 1://只改左上点坐标
                    add2(information.start_x+delta_x, information.start_y+delta_y,
                            information.end_x, information.end_y,
                            information.a1, information.a2, information.a3, information.a4);
                    break;
                case 2:
                    //右上点
                    add2(information.start_x, information.start_y+delta_y,
                            information.end_x+delta_x, information.end_y,
                            information.a1, information.a2, information.a3, information.a4);
                    break;
                case 3:
                    //左下点
                    add2(information.start_x+delta_x, information.start_y,
                            information.end_x, information.end_y+delta_y,
                            information.a1, information.a2, information.a3, information.a4);
                    break;
                case 4:
                    //只改右下点坐标
                    add2(information.start_x, information.start_y,
                            information.end_x+delta_x, information.end_y+delta_y,
                            information.a1, information.a2, information.a3, information.a4);
                    break;
                case 5:
                    //上边线
                    add2(information.start_x, information.start_y+delta_y,
                            information.end_x, information.end_y,
                            information.a1, information.a2, information.a3, information.a4);
                    break;
                case 6:
                    //下边线
                    add2(information.start_x, information.start_y,
                            information.end_x, information.end_y+delta_y,
                            information.a1, information.a2, information.a3, information.a4);
                    break;
                case 7:
                    //左边线
                    add2(information.start_x+delta_x, information.start_y,
                            information.end_x, information.end_y,
                            information.a1, information.a2, information.a3, information.a4);
                    break;
                case 8:
                    //右边线
                    add2(information.start_x, information.start_y,
                            information.end_x+delta_x, information.end_y,
                            information.a1, information.a2, information.a3, information.a4);
                    break;
                case 9:
                    //全局移动
                    add2(information.start_x+delta_x, information.start_y+delta_y,
                            information.end_x+delta_x, information.end_y+delta_y,
                            information.a1, information.a2, information.a3, information.a4);
                    break;
                default:;

            }
        }
    }
    class rec_box_move2 implements EventHandler<MouseEvent>{
        EventHandler<MouseEvent>move0,move1;
        Information information;
        int distract_flag=0;
        rec_box_move2(EventHandler<MouseEvent>move0,EventHandler<MouseEvent>move1,Information information,int k){
            this.move0=move0;
            this.move1=move1;
            this.information=information;
            this.distract_flag=k;
        }

        @Override
        public void handle(MouseEvent mouseEvent) {
           // System.out.println("release:"+delta_x+" "+delta_y);
            switch (distract_flag){
                case 1://只改左上点坐标
                    information.start_x= information.start_x+delta_x;
                    information.start_y=information.start_y+delta_y;

                    break;
                case 2:
                    //右上点
                    information.start_y=information.start_y+delta_y;
                    information.end_x=information.end_x+delta_x;

                    break;
                case 3:
                    //左下点
                    information.start_x= information.start_x+delta_x;
                    information.end_y= information.end_y+delta_y;

                    break;
                case 4:
                    //只改右下点坐标
                    information.end_x=information.end_x+delta_x;
                    information.end_y= information.end_y+delta_y;

                    break;
                case 5:
                    //上边线
                    information.start_y=information.start_y+delta_y;

                    break;
                case 6:
                    //下边线
                    information.end_y= information.end_y+delta_y;

                    break;
                case 7:
                    //左边线
                    information.start_x= information.start_x+delta_x;

                    break;
                case 8:
                    //右边线
                    information.end_x=information.end_x+delta_x;

                    break;
                case 9:
                    //全局移动
                    information.start_x= information.start_x+delta_x;
                    information.start_y=information.start_y+delta_y;
                    information.end_x=information.end_x+delta_x;
                    information.end_y= information.end_y+delta_y;

                    break;
                default:;

            }
            delta_x=0;
            delta_y=0;
            x0t=mouseEvent.getX();
            y0t= mouseEvent.getY();
            pane.removeEventHandler(MouseEvent.MOUSE_PRESSED,move0);
            pane.removeEventHandler(MouseEvent.MOUSE_DRAGGED,move1);
            pane.removeEventHandler(MouseEvent.MOUSE_RELEASED,this);

            //此处坐标纠偏是为了防止edit造成左上和右下坐标冲突问题
            information.coordinate_correct();
            information.change_to_String();
            System.out.println("一轮编辑release"+information.start_x+" "+information.start_y+ " "
            +information.end_x+" "+information.end_y);
        }}
}
