package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
public class run extends Application {

        public void start(Stage primaryStage) throws Exception{
            Parent root = FXMLLoader.load(getClass().getResource("test_recBox_move.fxml"));
            primaryStage.setTitle("picture marktool" );
            primaryStage.setScene(new Scene(root, 700, 675));
            primaryStage.show();

        }
    }

