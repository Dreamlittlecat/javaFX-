package sample;
import javafx.application.Application;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.StrokeLineCap;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class UI2Controller extends Application {
   Stage stage;
   File file;//当前图片文件
   File current_dir;//当前目录文件
   List<String> curr_pic_dir;//创建列表存放当前文件目录下的图片路径

   int ptr = 0;//指示curr_pic_dir的指针,设置指针为了实现next和prev功能

   List<Information> mark_list;//记录标注框信息
   Information information;//指示当前标注节点

   List<Information> read_mark_list;//读取到的标注框列表信息
   ObservableList<String> data;//显示文件列表
   Boolean markways_padding = false;//框选区域的需不需要填充

   //框选方式响应事件，框四边尺寸选择响应事件，框内填充不透明度设置响应事件
   Pad_event pad_event=new Pad_event();
   Size_choice_event size_choice_event=new Size_choice_event();
   Box_opacity_event box_opacity_event=new Box_opacity_event();

   @Override
   public void start(Stage stage) throws Exception {
      this.stage = stage;

   }

   @FXML
   private ColorPicker linecolor;
   @FXML
   private Label opacity_show;
   @FXML
   private Slider box_opacity;

   @FXML
   private TextField markfield;

   @FXML
   private Pane image_pane;
   @FXML
   private ImageView image_field;
   @FXML
   private StackPane Center_Stackpane;
   @FXML
   private ChoiceBox<String> mark_ways;

   @FXML
   private ChoiceBox<String> size_choice;
   ;
   @FXML
   private ColorPicker mark_area_color;

   @FXML
   private TextArea mark_area;
   @FXML
   private ListView<String> picfile_dir;

   @FXML
   void mynext(ActionEvent event) {
      System.out.println("\n调用mynext------");
      System.out.println("ptr:" + ptr);
      if (curr_pic_dir == null || ptr >= curr_pic_dir.size() - 1) {
         return;
      } else {
         String pic_temp_path = "file:///" + curr_pic_dir.get(++ptr);//image构造方法需要url,所以需要转换一下
         file = new File(curr_pic_dir.get(ptr));
         Image image = new Image(pic_temp_path);
         System.out.println(pic_temp_path);
         image_field.setImage(image);
         image_field.setPreserveRatio(true);
      }
      addwriteboard();
      System.out.println("ptr:" + ptr);
      read_sameName_xml();
      System.out.println("\n结束调用mynext------");

   }

   @FXML
   void myprev(ActionEvent event) {
      if (curr_pic_dir == null || ptr <= 0) {
         return;
      } else {
         String pic_temp_path = "file:///" + curr_pic_dir.get(--ptr);
         Image image = new Image(pic_temp_path);
         System.out.println(pic_temp_path);
         image_field.setImage(image);
         image_field.setPreserveRatio(true);
         addwriteboard();
         file = new File(curr_pic_dir.get(ptr));
         read_sameName_xml();
      }
   }

   Mark_event mark_event = new Mark_event();
   Edit_event edit_event = new Edit_event();

   @FXML
   void myedit(ActionEvent event) {
      image_pane.removeEventHandler(MouseEvent.MOUSE_PRESSED, mark_event);
      image_pane.addEventHandler(MouseEvent.MOUSE_PRESSED, edit_event);
   }

   @FXML
   void mymark(ActionEvent event) {
      image_pane.removeEventHandler(MouseEvent.MOUSE_PRESSED, edit_event);
      image_pane.addEventHandler(MouseEvent.MOUSE_PRESSED, mark_event);
   }

   //标记事件，添加标注框
   class Mark_event implements EventHandler<MouseEvent> {
      @Override
      public void handle(MouseEvent mouseEvent) {
         //更新标注框域
         update_mark_area();
         markfield.setText("");
         Double X, Y;
         X = mouseEvent.getX();
         Y = mouseEvent.getY();
         //添加框节点
         information = new Information();
         if (markways_padding) {
            information.Paddng = true;
            draw_rectangle2(X, Y, X, Y, information);
         } else {
            information.Paddng = false;
            draw_rectangle(X, Y, X, Y, information);
         }
         EventHandler<MouseEvent> eventHandler = new eventHandle(information);
         image_pane.addEventHandler(MouseEvent.MOUSE_DRAGGED, eventHandler);
         //监听鼠标release，一旦release，便移除对鼠标拖拽的监听，同时一移除对release的监听
         EventHandler<MouseEvent> eventHandler_realse = new eventHandle_realse(information,
                 mark_list, markfield, image_pane, eventHandler);
         image_pane.addEventHandler(MouseEvent.MOUSE_RELEASED, eventHandler_realse);

      }
   }

   //edit事件,选中框，改变当前框节点，实现框的移动和大小改变
   class Edit_event implements EventHandler<MouseEvent> {
      @Override
      public void handle(MouseEvent mouseEvent) {
         //进行遍历查找鼠标点击位置隶属于哪个框
         for (int i = 0; i < mark_list.size(); i++) {
            Information t = mark_list.get(i);
            if (mouseEvent.getX() > t.start_x && mouseEvent.getY() > t.start_y &&
                    mouseEvent.getX() < t.end_x && mouseEvent.getY() < t.end_y) {
               information = t;
               System.out.println("选中框：" + i);
               markfield.setText(t.mark_text);
               BigMachine_select_box2 bigMachine_select_box2 =
                       new BigMachine_select_box2(t, image_pane, mouseEvent.getX(), mouseEvent.getY());
               bigMachine_select_box2.select();
               break;
            }
         }
      }
   }


   @FXML
   void mymarkfield(ActionEvent event) {
      if (information != null) {
         information.mark_text = markfield.getText();
      }
      information.change_to_String();
      update_mark_area();
   }

   @FXML
   void mylinecolor(ActionEvent event) {
      if (information != null) {
         information.a1.setStroke(linecolor.getValue());
         information.a2.setStroke(linecolor.getValue());
         information.a3.setStroke(linecolor.getValue());
         information.a4.setStroke(linecolor.getValue());
         information.red = linecolor.getValue().getRed();
         information.green = linecolor.getValue().getGreen();
         information.blue = linecolor.getValue().getBlue();
         information.change_to_String();
      }
   }

   @FXML
   void myareacolor(ActionEvent event) {
      if (information != null) {
         information.r.setFill(new Color(mark_area_color.getValue().getRed(),
                 mark_area_color.getValue().getGreen(), mark_area_color.getValue().getBlue(), information.opacity));
         information.red = mark_area_color.getValue().getRed();
         information.green = mark_area_color.getValue().getGreen();
         information.blue = mark_area_color.getValue().getBlue();
         information.change_to_String();
      }
   }

   @FXML
   void mycdir(ActionEvent event) {
      FileChooser fileChooser = new FileChooser();
      // fileChooser.setTitle("Open desktop File");
      fileChooser.setTitle("View Pictures in cdir");
      if (current_dir == null) {  //fileChooser.setInitialDirectory(new File(System.getProperty("user.dir")));
         //首次打开目录，指定打开的文件夹
         fileChooser.setInitialDirectory(new File("C:\\Users\\xia23\\Pictures"));
      } else {
         fileChooser.setInitialDirectory(current_dir);
      }
      fileChooser.getExtensionFilters().addAll(
              new FileChooser.ExtensionFilter("JPG", "*.jpg"),
              new FileChooser.ExtensionFilter("PNG", "*.png"),
              new FileChooser.ExtensionFilter("GIF", "*.gif"),
              new FileChooser.ExtensionFilter("BMP", "*.bmp")

      );
      file = fileChooser.showOpenDialog(stage);
      fileJudge(file);//包括导入图片，获取当前目录下的图片文件操作
   }

   @FXML
   void myordir(ActionEvent event) {
      FileChooser fileChooser = new FileChooser();
      //  fileChooser.setTitle("Open original File");
      fileChooser.setTitle("View Pictures in ordir");
      fileChooser.setInitialDirectory(new File(System.getProperty("user.home"))

      );
      fileChooser.getExtensionFilters().addAll(
              new FileChooser.ExtensionFilter("JPG", "*.jpg"),
              new FileChooser.ExtensionFilter("PNG", "*.png"),
              new FileChooser.ExtensionFilter("GIF", "*.gif"),
              new FileChooser.ExtensionFilter("BMP", "*.bmp")
      );
      file = fileChooser.showOpenDialog(stage);//获得选取的文件
      fileJudge(file);//文件后续操作
   }

   //将图片导入imageview，并且执行addwriteboard();同时显示该目录下的图片文件，并对文件是否为图片文件进行筛选
   void fileJudge(File file) {
      if (!file.isFile()) {
         return;
      } else {
         Image image;//= new Image("https://pic.rmb.bdstatic.com/c86255e8028696139d3e3e4bb44c047b.png");
         image = new Image("file:///" + file.getAbsolutePath());//image构造方法需要url,所以需要转换一下
         image_field.setImage(image);
         image_field.setPreserveRatio(true);
         current_dir = new File(file.getParent());//将当前目录文件设置为当前文件的父目录
         curr_pic_dir = new ArrayList<>();
         File[] files = current_dir.listFiles();
         ptr = 0;

         List<String> file_temp = new ArrayList<>();
         System.out.println("图片目录show---------");
         System.out.println("files.length:" + files.length);
         int ptr_count = 0;//由于实际文件数目比图片文件数目大，所以添加一个ptr_count进行图片技术，以便图片指针指示正确位置
         for (int i = 0; i < files.length; i++) {
            //筛选相关后缀名的文件
            if (files[i].getName().replaceAll("(.jpg|.png|.bmp|.gif)+", "").length() != files[i].getName().length()) {
               System.out.println(files[i].getName());
               //增加列表行
               file_temp.add(files[i].getName());
               curr_pic_dir.add(file.getParent() + File.separator + files[i].getName());
               if (file.getName().equals(files[i].getName())) {
                  //设置初始选择的图片位置
                  ptr = ptr_count;
                  System.out.println("file_judge_ptr:" + ptr);
               }
               ptr_count++;
            }
         }
         data = FXCollections.observableArrayList(file_temp);
         picfile_dir.setItems(data);
         picfile_dir.getSelectionModel().selectedItemProperty().addListener(new pic_file_list());
         System.out.println("图片展示完毕------------");

         addwriteboard();
         read_sameName_xml();
      }
   }

   @FXML
   void mysave(ActionEvent event) {
      System.out.println("save----------");
      System.out.println(current_dir.getAbsolutePath());
      System.out.println(file.getName().replaceAll("(.jpg|.png|.bmp|.gif)+", "") + ".xml");
      Mark_xmlDom_write mark_xmlDom_write = new Mark_xmlDom_write(mark_list,
              current_dir.getAbsolutePath() + File.separator
                      + file.getName().replaceAll("(.jpg|.png|.bmp|.gif)+", "") + ".xml");
      mark_xmlDom_write.test();
      System.out.println("save----------over");
   }

   @FXML
   void myrestart(ActionEvent event) {
      addwriteboard();
      if(file!=null)
      read_sameName_xml();
   }

   @FXML
   void myclear(ActionEvent event) {
      addwriteboard();//更新面板
      mark_area.setText("");//mark_area清零
   }

   //更新写字板操作
   void addwriteboard() {
      //更新写字板相当于页面归零
      markfield.setText("");

      Center_Stackpane.getChildren().remove(image_pane);//移除上一个pane
      image_pane.getChildren().removeAll();//移除上一个pane的所有子组件
      image_pane = new AnchorPane();//建立新pane
      image_pane.setMaxSize(image_field.getFitWidth(), image_field.getFitHeight());//固定image_pane的尺寸与image_view尺寸保持一致，以便进行标注
      double W = image_field.getFitWidth(), H = image_field.getFitHeight();

      {//框出可标注区域，即对image_pane进行画框并设置该框的一些参数
         Information whiteboard_box = new Information();
         whiteboard_box.width = 3;
         whiteboard_box.red = 1;
         whiteboard_box.green = 1;
         whiteboard_box.blue =1;
         draw_rectangle(0, 0, W, H, whiteboard_box);
         Center_Stackpane.getChildren().add(image_pane);
      }
      mark_list = new ArrayList<>();//每次更新画板时建立标注框链表
      {
      //选择是否填充画框方式
      ObservableList cursors = FXCollections.observableArrayList("padding", "no-padding");
      mark_ways.setItems(cursors);
      mark_ways.getSelectionModel().selectedItemProperty().removeListener(pad_event);
      mark_ways.getSelectionModel().selectedItemProperty().addListener(pad_event);
      mark_ways.setValue("no-padding");
      //设置不透明度监听事件
      box_opacity.valueProperty().removeListener(box_opacity_event);
      box_opacity.valueProperty().addListener(box_opacity_event);
      box_opacity.setValue(0.0);
      //选择框四条线的尺寸
      cursors = FXCollections.observableArrayList("1", "2", "3", "4", "5");
      size_choice.setItems(cursors);
      size_choice.getSelectionModel().selectedItemProperty().removeListener(size_choice_event);
      size_choice.getSelectionModel().selectedItemProperty().addListener(size_choice_event);
      size_choice.setValue("1");
      }
   }

   //读取同名xml文件，实现加框操作
   void read_sameName_xml() {
      System.out.println("进入加框函数---------------");
      File temp = new File(file.getParent() + File.separator
              + file.getName().replaceAll("(.jpg|.png|.bmp|.gif)+", "") + ".xml");
      System.out.println(temp);
      mark_area.setText("");
      if (temp.isFile()) {
         System.out.println("加框");
         read_mark_list = new ArrayList<>();
         Mark_xmlDom_read mark_xmlDom_read = new Mark_xmlDom_read(read_mark_list, temp.getAbsolutePath());
         mark_xmlDom_read.Read();
         for (int i = 0; i < read_mark_list.size(); i++) {
            System.out.println("第i个框：" + i);
            Information t = read_mark_list.get(i);
            t.change();
            if (t.Paddng) {
               draw_rectangle2(t.start_x, t.start_y, t.end_x, t.end_y, t);
            } else {
               draw_rectangle(t.start_x, t.start_y, t.end_x, t.end_y, t);
            }

            //保留原有的画框，需要用read_mark_list初始化mark_list
            mark_list.add(t);
            //更新mark_area
            mark_area.appendText("mark" + (i + 1) + ":" + t.mark_text + "\n");
         }
      }
      System.out.println("退出加框函数--------------");

   }

   //画框函数
   void draw_rectangle(double x0, double y0, double x1, double y1, Information t) {
      Line a1 = t.a1;
      Line a2 = t.a2;
      Line a3 = t.a3;
      Line a4 = t.a4;
      a1.setStartX(x0);
      a2.setStartX(x0);
      a3.setStartX(x1);
      a4.setStartX(x0);
      a1.setStartY(y0);
      a2.setStartY(y0);
      a3.setStartY(y0);
      a4.setStartY(y1);
      a1.setEndX(x1);
      a2.setEndX(x0);
      a3.setEndX(x1);
      a4.setEndX(x1);
      a1.setEndY(y0);
      a2.setEndY(y1);
      a3.setEndY(y1);
      a4.setEndY(y1);
      image_pane.getChildren().add(a1);
      image_pane.getChildren().add(a2);
      image_pane.getChildren().add(a3);
      image_pane.getChildren().add(a4);
      Paint temp = new Color(t.red, t.green, t.blue, 1);
      a1.setStroke(temp);
      a2.setStroke(temp);
      a3.setStroke(temp);
      a4.setStroke(temp);
      a1.setStrokeWidth(t.width);
      a2.setStrokeWidth(t.width);
      a3.setStrokeWidth(t.width);
      a4.setStrokeWidth(t.width);
   }
   void draw_rectangle2(double x0, double y0, double x1, double y1, Information t) {
      Rectangle r = t.r;
      r.setX(x0);
      r.setY(y0);
      r.setWidth(x1 - x0);
      r.setHeight(y1 - y0);
      image_pane.getChildren().add(r);
      //框的四边
      r.setStroke(new Color(0, 0.5, 0, 1));
      //框的填充
      r.setFill(new Color(t.red, t.green, t.blue, t.opacity));

   }

   //更新mark_area
   void update_mark_area() {
      if (mark_list != null) {
         mark_area.setText("");
         for (int i = 0; i < mark_list.size(); i++) {
            Information t = mark_list.get(i);
            t.change();
            //更新mark_area
            mark_area.appendText("mark" + (i + 1) + ":" + t.mark_text + "\n");
         }
      }
   }

   @FXML
   void myabout(ActionEvent event) {
      Stage secondStage = new Stage();
      Parent rootk;
      try {
         rootk = FXMLLoader.load(getClass().getResource("secondscene.fxml"));
         secondStage.setTitle("about");
         secondStage.setScene(new Scene(rootk, 600, 500));
         secondStage.show();
      } catch (IOException e) {
         e.printStackTrace();
      }
   }

   //图片文件列表单行响应事件
   class pic_file_list implements InvalidationListener {
      @Override
      public void invalidated(Observable observable) {
         //提取选中的文件名
         String temp = observable.toString();
         temp = temp.substring(temp.lastIndexOf("value:"), temp.length() - 1);
         temp = temp.substring(temp.lastIndexOf(" "));
         temp = temp.substring(1);
         //改变当前文件，进行文件判决
         file = new File(file.getParent() + File.separator + temp);
         //移除事件响应
         picfile_dir.getSelectionModel().selectedItemProperty().removeListener(this);
         fileJudge(file);
      }
   }
   class Pad_event implements ChangeListener<String>{
      @Override
      public void changed(ObservableValue<? extends String> observableValue, String s, String t1) {
         if("padding".equals(t1)){
            markways_padding = true;
         }else if(t1.equals("no-padding")){
            markways_padding=false;
         }
      }
   }
   class Box_opacity_event implements ChangeListener<Number>{
      @Override
      public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
         if (information != null) {
            information.opacity = t1.doubleValue() / 100;
            information.r.setFill(new Color(information.red, information.green, information.blue, information.opacity));
            information.change_to_String();
         }
         opacity_show.setText(t1.intValue() + "%");
      }
   }
   class Size_choice_event implements ChangeListener<String>{
      @Override
      public void changed(ObservableValue<? extends String> observableValue, String s, String t1) {

         if (information != null) {
            information.width = Integer.parseInt(t1);
            System.out.println("size:"+information.width);
            information.change_to_String();
            information.a1.setStrokeWidth(information.width);
            information.a2.setStrokeWidth(information.width);
            information.a3.setStrokeWidth(information.width);
            information.a4.setStrokeWidth(information.width);
         }
      }
   }
}
