package sample;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.List;

public class Mark_xmlDom_read {
    static List<Information>list;
    static String file_path;
    Mark_xmlDom_read(List<Information> list,String file_path){
        this.list=list;
        this.file_path=file_path;
    }

    public static void Read() {
        //创建一个DocumentBuilderFactory的对象
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        try {
            //创建DocumentBuilder对象
            DocumentBuilder db = dbf.newDocumentBuilder();
            //通过DocumentBuilder对象的parser方法加载.xml文件到当前项目下
            Document document = null;
            try {
                document = db.parse(file_path);
            } catch (org.xml.sax.SAXException e) {
                e.printStackTrace();
            }
            NodeList markList = document.getElementsByTagName("mark");

            System.out.println("一共有" + markList.getLength() + "个标注框");
            //遍历节点
            for (int i = 0; i < markList.getLength(); i++) {

                Information information=new Information();
                //System.out.println("=================下面开始遍历第" + (i + 1) + "个标注框的内容=================");
                //通过 item(i)方法 获取一个节点，nodelist的索引值从0开始
                Node mark = markList.item(i);
                //获取所有属性集合
                NamedNodeMap attrs = mark.getAttributes();


                //遍历属性
                for (int j = 0; j < attrs.getLength(); j++) {
                    //通过item(index)方法获取节点的某一个属性
                    Node attr = attrs.item(j);
                    //获取属性名
                 //   System.out.print("属性名：" + attr.getNodeName());
                    //获取属性值
                 //   System.out.println("--属性值" + attr.getNodeValue());
                }
                //解析节点的子节点
                NodeList childNodes = mark.getChildNodes();

                //遍历子节点，childNodes获取每个节点的节点名和节点值
             //   System.out.println("第" + (i+1) + "个节点（标注框）共有" +
                //        childNodes.getLength() + "个子节点");
                for (int k = 0; k < childNodes.getLength(); k++) {
                    //区分出text类型的node以及element类型的node
                    if (childNodes.item(k).getNodeType() == Node.ELEMENT_NODE) {
                        //获取了element类型节点的节点名
                   //     System.out.print("第" + (k + 1) + "个子节点的节点名："
                   //             + childNodes.item(k).getNodeName());
                        //获取了element类型节点的节点值
                       // System.out.println("--节点值是：" + childNodes.item(k).getFirstChild().getNodeValue());
                    //    System.out.println("--节点值是：" + childNodes.item(k).getTextContent());
                        String name=childNodes.item(k).getNodeName();
                        String value=childNodes.item(k).getTextContent();
                        if("color".equals(name)){
                            information.color=value;
                        }else if("size".equals(name)){
                            information.size=value;
                        }else if("start_coordinate".equals(name)){
                            information.start_coordinate=value;
                        }else if("end_coordinate".equals(name)){
                            information.end_coordinate=value;
                        }else if("mark_text".equals(name)){
                            information.mark_text=value;
                        }
                    }
                }
                list.add(information);
            //    System.out.println("======================结束遍历第" + (i + 1) + "个标注框的内容=================");
            }
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(list);

    }

}
