package sample;

import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;

public class eventHandle implements EventHandler<MouseEvent> {
    Line line ;
    Rectangle r;
    Boolean r_flag=false,line4_flag=false,line_flag=false;
    Line l1,l2,l3,l4;
    Information information;
    eventHandle(Line line){
        this.line=line;
        line_flag=true;
    }
    eventHandle(Rectangle r){
        this.r=r;
        r_flag=true;
    }
    eventHandle(Information information){
        if(information.Paddng){
            r_flag=true;
            r=information.r;
        }else{
        this.l1=information.a1;
        this.l2=information.a2;
        this.l3=information.a3;
        this.l4=information.a4;
        line4_flag=true;}
    }
    public void handle(MouseEvent mouseEvent2){
        if(line_flag){//画线
            line.setEndX(mouseEvent2.getX());
            line.setEndY(mouseEvent2.getY());}
        double x= mouseEvent2.getX();
        double y=mouseEvent2.getY();
        if(r_flag){//画矩形
            r.setWidth(x-r.getX());
            r.setHeight(y-r.getY());
        }
        if(line4_flag){//画框
            l1.setEndY(y);
            l1.setEndX(l1.getStartX());
            l2.setEndX(x);
            l2.setEndY(l2.getStartY());
            l3.setEndY(y);
            l3.setEndX(x);
            l3.setStartY(y);
            l4.setEndX(x);
            l4.setEndY(y);
            l4.setStartX(x);

        }
    }
}
