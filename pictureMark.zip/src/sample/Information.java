package sample;

import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;

public class Information {
    //存文件一套，主要针对坐标
    String color;//color格式  red-k green-k blue-k opacity-k padding-k
    String mark_text;
    String start_coordinate;
    String end_coordinate;
    String size;
    //用时候另一套
    double start_x,start_y,end_x,end_y;
    Line a1,a2,a3,a4;//框

    Rectangle r = new Rectangle();//填充
    Boolean Paddng=false;
    int width=1;
    double red=0.8,blue=0,green=0,opacity=0.5;//根据color的构造函数，默认是红色
    Information(){
        //初始化四根线，便于移动每个框
        a1=new Line();
        a2=new Line();
        a3=new Line();
        a4=new Line();
    }

    //存的转用的
    public void change(){

        int start=start_coordinate.indexOf('-');
        start_x=Double.parseDouble(start_coordinate.substring(0,start-1));
        start_y=Double.parseDouble(start_coordinate.substring(start+1,start_coordinate.length()-1));
        int end=end_coordinate.indexOf('-');
        end_x=Double.parseDouble(end_coordinate.substring(0,end-1));
        end_y=Double.parseDouble(end_coordinate.substring(end+1,end_coordinate.length()-1));

       //在这里进行一次坐标纠偏，防止读取文件中出现的差错数据
        coordinate_correct();
        width=Integer.parseInt(size);
        if(color!=null){
            int r,g,b,o,p;
            r=color.indexOf("r-");
            g=color.indexOf("g-");
            b=color.indexOf("b-");
            o=color.indexOf("o-");
            p=color.indexOf("p-");
            red=Double.parseDouble(color.substring(r+2,g));
            green=Double.parseDouble(color.substring(g+2,b));
            blue=Double.parseDouble(color.substring(b+2,o));
            opacity=Double.parseDouble(color.substring(o+2,p));
            Paddng="true".equals(color.substring(p+2));
        }
    }
    //用的转存的
    public void change_to_String(){
        coordinate_correct();
        start_coordinate=start_x+"-"+start_y;
        end_coordinate=end_x+"-"+end_y;
        size=width+"";
        color="r-"+red+"g-"+green+"b-"+blue+"o-"+opacity+"p-"+Paddng;
    }
    //标注框分区
    public int judgeDistract(double x,double y){
        //1_left-up point ,2_right-up point ,3_left_down point ,4_right_down point
        //5_up-line , 6_down-line, 7_left-line ,8-right-line
        //9_move_center
        int point_size=10;
        double x_0=start_x+point_size;
        double y_0=start_y+point_size;
        double x_1=end_x-point_size;
        double y_1=end_y-point_size;
        if(x>x_0&&x<x_1&&y>y_0&&y<y_1){
            return 9;
        }else if(x>=start_x&&x<x_0&&y>=start_y&&y<y_0){
            return 1;
        }else if(x<end_x&&x>=x_1&&y<end_y&&y>=y_1){
            return 4;
        }else if(x>=x_1&&x<end_x&&y>=start_y&&y<y_0){
            return 2;
        }else if(x>=start_x&&x<x_0&&y>=y_1&&y<end_y){
            return 3;
        }else if(x>x_0&&x<x_1&&y>start_y&&y<y_0){
            return 5;
        }else if(x>x_0&&x<x_1&&y>y_1&&y<end_y){
            return 6;
        }else if(x>start_x&&x<x_0&&y>y_0&&y<y_1){
            return 7;
        }else{
            return 8;
        }
    }
    //坐标纠偏，左上坐标大于右下坐标时及时交换
    public void coordinate_correct(){
        if(this.start_x> this.end_x){
            double temp= this.end_x;;
            this.end_x= this.start_x;;
            this.start_x=temp;
        }
        if(this.start_y> this.end_y){
            double temp= this.end_y;;
            this.end_y= this.start_y;;
            this.start_y=temp;
        }
    }
    public String toString(){
        return "color:"+color+" mark_text:"+mark_text+" start_x_y:"+start_coordinate+" end_x_y:"+end_coordinate+" size:"+size+"\n";
             //   +start_x+" "+start_y+" "+end_x+" "+end_y;
    }
    public Boolean isBox(){
        //为了解决pressed-released而没有拖拽从而添加的框是一个点的问题；
        if(this.start_x==this.end_x&&this.end_y==this.start_y)
            return false;
        return true;
    }

}