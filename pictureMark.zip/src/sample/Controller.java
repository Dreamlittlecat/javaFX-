package sample;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;

public class Controller extends Application {
    Stage stage;

    @FXML
    private Button next;

    @FXML
    private MenuItem save_;

    @FXML
    private TextArea pctextarea;

    @FXML
    private Button prev;

    @FXML
    private MenuBar filemenu;

    @FXML
    private MenuItem about;

    @FXML
    private Button conserve;

    @FXML
    private Label mark_tools;

    @FXML
    private ImageView image_field;

    @FXML
    private MenuItem open1;

    @FXML
    private MenuItem open2;

    @FXML
    private GridPane window;

    @FXML
    private AnchorPane panel;

    @FXML
    private TextArea mark_text;

    @FXML
    void mysave(ActionEvent event) {

    }

    @FXML
    void mynext(ActionEvent event) {

    }

    @FXML
    void myprev(ActionEvent event) {

    }

   /* @FXML
    void 6f5f12(ActionEvent event) {

    }*/

    @FXML
    void myfilemenu(ActionEvent event) {

    }

    @FXML
    void myopen1(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Resource File");
        fileChooser.showOpenDialog(stage);
        fileChooser.setTitle("View Pictures");
        fileChooser.setInitialDirectory(new File(System.getProperty("user.home"))
        );
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("JPG", "*.jpg"),
                new FileChooser.ExtensionFilter("PNG", "*.png")
        );


    };


    @FXML
    void myopen2(ActionEvent event) {

    }

    @FXML
    void mysave_(ActionEvent event) {

    }

    @FXML
    void myabout(ActionEvent event) {

    }

    @Override
    public void start(Stage stage) throws Exception {
        this.stage=stage;
    }
}
