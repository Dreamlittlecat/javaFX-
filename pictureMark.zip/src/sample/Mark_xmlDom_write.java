package sample;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.util.List;
public class Mark_xmlDom_write {
//xml文件写入
    static List<Information>list;
    static String file_path;
    Mark_xmlDom_write(List<Information> list, String file_path){
        this.list=list;
        this.file_path=file_path;
    }
    public void test(){
        Long start = System.currentTimeMillis();
        createXml();
        System.out.println("运行时间："+ (System.currentTimeMillis() - start));
    }

    public static void createXml(){
        try {
            // 创建解析器工厂
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = factory.newDocumentBuilder();
            Document document = db.newDocument();
            // 不显示standalone="no"
            document.setXmlStandalone(true);
            test_2(document, list);
            // 创建TransformerFactory对象
            TransformerFactory tff = TransformerFactory.newInstance();
            // 创建 Transformer对象
            Transformer tf = tff.newTransformer();
            // 输出内容是否使用换行
            tf.setOutputProperty(OutputKeys.INDENT, "yes");
            // 创建xml文件并写入内容
            tf.transform(new DOMSource(document), new StreamResult(new File(file_path)));
            System.out.println("生成.xml成功");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("生成.xml失败");
        }
    }

    static void test_2(Document document,List<Information>list){
        Element root = document.createElement("Marks");
        for(int i=0;i<list.size();i++){

            Information t= list.get(i);
            //用的转成存的，更新坐标文本，因为是写文件的出口
            t.change_to_String();

            //下面将information节点的String内容写入到相应文本
            Element child=document.createElement("mark");

            Element mark_text=document.createElement("mark_text");
            mark_text.setTextContent(list.get(i).mark_text);

            Element color=document.createElement("color");
            color.setTextContent(list.get(i).color);

            Element start=document.createElement("start_coordinate");
            start.setTextContent(list.get(i).start_coordinate);

            Element end=document.createElement("end_coordinate");
            end.setTextContent(list.get(i).end_coordinate);

            Element size=document.createElement("size");
            size.setTextContent(list.get(i).size);

            child.appendChild(mark_text);
            child.appendChild(color);
            child.appendChild(size);child.appendChild(start);child.appendChild(end);

            child.setAttribute("id", String.valueOf(i+1));
            root.appendChild(child);
        }
        document.appendChild(root);

    }
    static  void initList(int n,List<Information> list){
        for(int i=0;i<n;i++){
            Information information=new Information();
            information.size=i+"1";
            information.color="pink";
            information.start_coordinate="100-"+String.valueOf(i)+"00";
            information.end_coordinate="0-0";
            information.mark_text="这是第"+String.valueOf(i+1)+"个大聪明";
            list.add(information);
        }
    }

}